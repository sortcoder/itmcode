<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BuyPackages extends Model
{
    use HasFactory;
    protected $table = 'buy_package';
}
