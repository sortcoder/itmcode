<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LaunchpaidData extends Model
{
    use HasFactory;
    protected $table = 'launch_paid_data';
}
