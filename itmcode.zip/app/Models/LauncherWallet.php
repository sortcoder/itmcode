<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LauncherWallet extends Model
{   
    protected $table = 'launcher_wallet';
    use HasFactory;
}
