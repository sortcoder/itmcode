<header>
    <div class="topbar d-flex align-items-center">
        <nav class="navbar navbar-expand">
            <div class="mobile-toggle-menu"><i class='bx bx-menu'></i>
            </div>
            <div class="search-bar flex-grow-1">
                <div class="position-relative search-bar-box">
                    
                </div>
            </div>
            <div class="top-menu ms-auto">
                <ul class="navbar-nav align-items-center">

                </ul>
            </div>
            <div class="user-box dropdown">
                <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="<?php echo e(asset('assets/admin/images/mainlogo.png')); ?>" class="user-img" style="width: 77px;" alt="user avatar">
                    <div class="user-info ps-3">
                        <p class="user-name mb-0"><?php echo e(Auth::user()->name); ?></p>
                         <?php if(!empty(Auth::user()->getRoleNames())): ?>
                                <?php $__currentLoopData = Auth::user()->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="designattion mb-0"><?php echo e($v); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>

                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    
                    <li><a class="dropdown-item" href="javascript:;" data-logout-click="<?php echo e(route('logout')); ?>"><i class='bx bx-log-out-circle'></i><span>Logout</span></a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>

<?php /**PATH /var/www/html/itm/resources/views/admin/layouts/header.blade.php ENDPATH**/ ?>