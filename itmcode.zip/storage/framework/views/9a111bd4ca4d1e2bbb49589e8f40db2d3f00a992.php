<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<style>
label{
    font-weight: 600 !important;
}
</style>
<?php $__env->stopSection(); ?>


    <div class="card">
        <div class="card-header"><h6>Lauch Paid Package </h6></div>
        <div class="card-body">

            <div class="alertError" style="display: none;">

            </div>

            <div class="row">
                <div class="col-4 mt-2">
                    <label for="quantity">Quantity</label>
                    <p>  <?php echo e($user->quantity); ?></p>
                </div>
                <div class="col-4 mt-2">
                    <label for="price">One Image Price</label>
                    <p>  <?php echo e(config('app.currency').$user->one_image_price); ?></p>
                </div>
                <div class="col-4 mt-2">
                    <label for="price">Price</label>
                    <p>  <?php echo e(config('app.currency').$user->price); ?></p>
                </div>
                <div class="col-12 mt-2">
                    <label for="price">Description</label>
                    <p>  <?php echo e($user->description); ?></p>
                </div>
            </div>

        </div>
    </div>


</div>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/itm/resources/views/admin/package/show.blade.php ENDPATH**/ ?>