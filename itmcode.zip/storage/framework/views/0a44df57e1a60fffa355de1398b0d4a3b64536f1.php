<footer class="page-footer">
    <p class="mb-0">Copyright © <?php echo e(date('Y')); ?>. All right reserved.</p>
</footer>
<?php /**PATH /var/www/html/itm/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>