<style> .btn { margin: 0px 2px; }</style>
<div class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
        <div>
            <img src="<?php echo e(asset('assets/admin/images/mainlogo.png')); ?>" class="logo-icon" alt="logo icon">
        </div>
        <div>
            <h4 class="logo-text">ITM Money</h4>
        </div>
        <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
        </div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">
        <li>
            <a href="<?php echo e(route('dashboard')); ?>" >
                <div class="parent-icon"><i class='bx bx-home-circle'></i>
                </div>
                <div class="menu-title">Dashboard</div>
            </a>

        </li>
         
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Roles-Permission-Management')): ?>
            <li>
                <a href="javascript:;" class="has-arrow">
                    <div class="parent-icon"><i class="bx bx-user"></i>
                    </div>
                    <div class="menu-title">Role & Management</div>
                </a>
                <ul> 
                    <li> <a href="<?php echo e(route('roles.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Roles</a>
                    </li>
                    <li> <a href="<?php echo e(route('users.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Users</a>
                    </li> 
                </ul>
            </li>
        <?php endif; ?> 
        
        <li class="menu-label">App Modules</li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('User-Management')): ?>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-user"></i>
                </div>
                <div class="menu-title">User Management</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('appuser.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Users</a>
                </li>
                <li>
                    <a href="<?php echo e(route('professional.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Profession</a>
                </li>
                <li>
                    <a href="<?php echo e(route('designation.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Designation</a>
                </li>
                
            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Package-Management')): ?>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-category"></i>
                </div>
                <div class="menu-title">Package Management</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('package.create')); ?>"><i class="bx bx-right-arrow-alt"></i>Add Package</a>
                </li>
                <li>
                    <a href="<?php echo e(route('package.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Package List</a>
                </li>

            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Video-Management')): ?>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-video"></i>
                </div>
                <div class="menu-title">Video Management</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('video.create')); ?>"><i class="bx bx-right-arrow-alt"></i>Add Video</a>
                </li>
                <li>
                    <a href="<?php echo e(route('video.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Video List</a>
                </li>

            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Launch-Paid-Management')): ?>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-paper-plane"></i>
                </div>
                <div class="menu-title">Launch Paid Management</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('launchpaid.create')); ?>"><i class="bx bx-right-arrow-alt"></i>Create Demo Launch Paid</a>
                </li>
                <!-- <li>
                    <a href="<?php echo e(route('launch_image')); ?>"><i class="bx bx-right-arrow-alt"></i>Launch Image  </a>
                </li> -->
                <li>
                    <a href="<?php echo e(route('launch_image_icon')); ?>"><i class="bx bx-right-arrow-alt"></i>Upcomming ICO</a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('demo_launcher')); ?>?created_by=true&live=false"><i class="bx bx-right-arrow-alt"></i>Demo Launcher Image</a>
                </li>
                <li>
                    <a href="<?php echo e(route('live_launcher')); ?>?created_by=true&live=true"><i class="bx bx-right-arrow-alt"></i>User Launcher Image</a>
                </li>
            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Trading-Management')): ?>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-line-chart-down"></i>
                </div>
                <div class="menu-title">Trading Management</div>
            </a>
            <ul> 
                <li>
                    <a href="<?php echo e(route('launch_image_tradding',2)); ?>"><i class="bx bx-right-arrow-alt"></i>Live Trading Images </a>
                </li>
                <li>
                    <a href="<?php echo e(route('launch_image_tradding',1)); ?>"><i class="bx bx-right-arrow-alt"></i>Demo Trading Images </a>
                </li>
                <li>
                    <a href="<?php echo e(route('buy_more_request.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Buy More Image Request </a>
                </li>
            </ul>
        </li>
        <?php endif; ?> 
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Order-Management')): ?>
            <li>
                <a href="javascript:;" class="has-arrow">
                    <div class="parent-icon"><i class="bx bx-cart"></i>
                    </div>
                    <div class="menu-title">Order Management</div>
                </a>
                <ul>
                    <li>
                        <a href="<?php echo e(route('manage_order.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Order List</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('upcomming_order.index')); ?>"><i class="bx bx-right-arrow-alt"></i>ICO Order</a>
                    </li> 
                    <!-- <li>
                        <a href="<?php echo e(route('order-list')); ?>"><i class="bx bx-right-arrow-alt"></i>Order List</a>
                    </li> -->
                </ul>
            </li>
        <?php endif; ?> 
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Payment-Management')): ?>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-money"></i>
                </div>
                <div class="menu-title">Payment Management</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('launcher_list')); ?>"><i class="bx bx-right-arrow-alt"></i>Credit Balance </a>
                </li>
                <li>
                    <a href="<?php echo e(route('withdraw.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Withdraw Request </a>
                </li> 
                <li>
                    <a href="<?php echo e(route('user_transaction')); ?>"><i class="bx bx-right-arrow-alt"></i>Payment Transaction</a>
                </li>
                <!-- <li>
                    <a href="<?php echo e(route('transfer_money_transaction')); ?>"><i class="bx bx-right-arrow-alt"></i>Transfer Money Transaction </a>
                </li> -->
                <li>
                    <a href="<?php echo e(route('history_user_transaction')); ?>"><i class="bx bx-right-arrow-alt"></i>Wallet Transactions</a>
                </li>
                <li>
                    <a href="<?php echo e(route('credited_users')); ?>"><i class="bx bx-right-arrow-alt"></i>Credit History</a>
                </li>
            </ul>
        </li>
        <?php endif; ?> 
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Notification')): ?>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-bell"></i>
                </div>
                <div class="menu-title">Notification</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('notification.create')); ?>"><i class="bx bx-right-arrow-alt"></i>Add Notification</a>
                </li>
                <li>
                    <a href="<?php echo e(route('notification.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Notification List</a>
                </li>
            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Banner-Management')): ?>


        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-image"></i>
                </div>
                <div class="menu-title">Banner Management</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('banner.create')); ?>"><i class="bx bx-right-arrow-alt"></i>Add Banner</a>
                </li>
                <li>
                    <a href="<?php echo e(route('banner.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Banner List</a>
                </li>
            </ul>
        </li>
        <?php endif; ?>

        <li class="menu-label">Others</li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Setting-Management')): ?>

        <li> 
            <a href="<?php echo e(route('contact.index')); ?>" >
                <div class="parent-icon"><i class='bx bx-envelope'></i>
                </div>
                <div class="menu-title">Customer Support</div>
            </a>
        </li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="bx bx-user"></i>
                </div>
                <div class="menu-title">Settings</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('setting_config.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Basic Setting</a>
                </li>

            </ul>
        </li>
        <?php endif; ?>
        <li>
            <a data-logout-click="<?php echo e(route('logout')); ?>" href="javascript:;">
                <div class="parent-icon"><i class="bx bx-lock"></i>
                </div>
                <div class="menu-title">Logout</div>
            </a> 
        </li>
    </ul>
    <!--end navigation-->
</div>
<?php /**PATH /var/www/html/itm/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>