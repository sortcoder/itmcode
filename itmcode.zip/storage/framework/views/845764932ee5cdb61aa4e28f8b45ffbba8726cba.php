<?php $__env->startSection('content'); ?>

<div class="card">

	<div class="card-body">
		<h5><?php echo e($title); ?></h5>

		<hr>


				<div class="row">
					<div class="col-12">
						<label><b>Name</b></label>
						<p><?php echo e($role->name); ?> </p>
					</div>
					<div class="col-12">
                        <div class="form-group">
                            <strong>Permissions:</strong><br><br>
                            <?php if(!empty($rolePermissions)): ?>
                            <?php
                                $count =1;
                            ?>
                                <?php $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="label label-success"><?php echo e($count++); ?>:  <?php echo e($v->name); ?>,</label><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>

	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/itm/resources/views/admin/roles/show.blade.php ENDPATH**/ ?>