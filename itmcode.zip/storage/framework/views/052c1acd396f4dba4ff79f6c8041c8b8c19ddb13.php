<?php $__env->startSection('content'); ?>

<div class="card">

	<div class="card-body">
		<h5><?php echo e($title); ?></h5>

		<hr>


				<div class="row">
					<div class="col-6">
						<label>Name</label>
						<p><?php echo e($user->name); ?> </p>
					</div>
					<div class="col-6">
						<label>Email</label>
						<p><?php echo e($user->email); ?> </p>
					</div>
					<div class="col-6">
						<label>Mobile</label>
						<p><?php echo e($user->mobile); ?> </p>
					</div>
					<div class="col-6">
						<label>Roles</label><br>
						<?php if(!empty($user->roles))
                        {
                            foreach($user->roles as $key => $role) {
                                echo '<span class="badge bg-primary">'.$role->name.'</span>';
                            }
                        }
?>

					</div>
					<div class="col-6">
						<label>Status</label>
                        <p><?=[''=>'Select Status',1=>'Inactive',2=>'Active'][$user->status]?></p>


					</div>


	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/itm/resources/views/admin/users/show.blade.php ENDPATH**/ ?>