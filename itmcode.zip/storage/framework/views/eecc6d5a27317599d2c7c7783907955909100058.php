<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <div class="title">
                <h5><?php echo e($title); ?></h5>
            </div>
            <div class="addbutton">
               <!--  <a href="<?php echo e(route('setting_config.create')); ?>" class="btn btn-primary btn-sm">+ Add New Variable </a> -->
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-sm">

                <tbody>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Value</th>
                        <th>Action</th>
                    </tr>
                    <?php if(isset($records)): ?>
                    <?php
                        $sr = 1;
                    ?>

                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sr++); ?></td>
                                <td><?php echo e($obj->var_name); ?></td>
                                <td>
                                    <?php
                                        $in = strip_tags(settingConfig($obj->var_key));
                                        $out = strlen($in) > 60 ? substr($in,0,60)."..." : $in;

                                    ?>
                                    <?php echo $out; ?></td>
                                <td><a href="<?php echo e(route('setting_config.edit',[encodeId($obj->id)])); ?>" class="btn btn-outline-primary ml-2 btn-sm mr-2">Edit</a>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/itm/resources/views/admin/setting_config/index.blade.php ENDPATH**/ ?>