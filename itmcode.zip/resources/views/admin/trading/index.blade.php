@extends('admin.layouts.app')

@section('content')
@section('style')
<link rel="stylesheet" href="{{  asset('assets/admin/css/dataTables.bootstrap5.min.css') }}">
@endsection

<div class="card">
    <div class="card-header">
        <h6>Trading Image List</h6>
    </div>
    <div class="card-body">

    </div>
</div>
@endsection
