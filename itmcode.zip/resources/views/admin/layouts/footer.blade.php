<footer class="page-footer">
    <p class="mb-0">Copyright © {{ date('Y') }}. All right reserved.</p>
</footer>
