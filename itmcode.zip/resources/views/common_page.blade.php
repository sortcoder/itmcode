
<!DOCTYPE html><html lang="en-IN"><head><meta charSet="utf-8"/><meta http-equiv="X-UA-Compatible" content="IE=edge"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>ITM Money</title><meta name="author" content="ITM Money"/><meta name="generator" content="Starfield Technologies; Go Daddy Website Builder 8.0.0000"/> 
 
<meta property="og:site_name" content="ITM Money"/>
<meta property="og:title" content="ITM Money"/>
<meta property="og:type" content="website"/> 
<meta property="og:locale" content="en_IN"/>
<meta name="twitter:card" content="summary"/>
<meta name="twitter:title" content="ITM Money"/>
<meta name="twitter:description" content="COMING SOON"/> 
<meta name="twitter:image:alt" content="ITM Money"/>
 </head>

<style> 
  .active_cls{ color: #f686ce !important; }
  .nav_mn li a{ color: white; text-decoration: none; }
  .maan{ 
    border-bottom: 1px solid #d3d3d394;
    padding:10px 5px 10px;
    display: flex;
    flex: none; 
    justify-content: space-between;
  }
  .maan ul{
    display: flex;
    font-family: "Poppins",Arial,sans-serif;
  }
  .logo-new img {
    width: 80px;
    padding-left: 24px;
    
}
.maan .nav_mn li {
    display: inline-block;
    font-size: 20px;
    padding: 0 20px;
    margin-top: 10px;
}
.nav_mn{
    padding-right: 43px;
}
</style>
<div class="maan">
    <div class="logo-new">
         <a href="{{ url('/')}}"><img src="{{ url('assets/admin/images/mainlogo.png') }}" /></a>
    </div>
    <div > 
    </div>
</div> 
<body class="x  x-fonts-muli" style="margin: 0;">
  <div style="margin: 5% !important;">
      <h1>{{ $page_title }}</h1><hr/>
      <div>
        {!! $page_content !!}
      </div>
  </div>
<script type="text/javascript">"IntersectionObserver"in window&&"Intl"in window&&"Locale"in window.Intl||document.write(`\x3Cscript src="https://img1.wsimg.com/poly/v3/polyfill.min.js?rum=0&unknown=polyfill&flags=gated&features=Intl.~locale.en-IN">\x3C/script>`)</script>
<script src="//img1.wsimg.com/blobby/go/e954c62d-c920-4c98-8efd-b8ae6be88b51/gpub/54bd5371694799c2/script.js" crossorigin></script>
<script src="//img1.wsimg.com/ceph-p3-01/website-builder-data-prod/static/widgets/UX.4.25.3.js" crossorigin></script>
<script src="//img1.wsimg.com/blobby/go/e954c62d-c920-4c98-8efd-b8ae6be88b51/gpub/b03a8c8858993f89/script.js" crossorigin></script>
<script defer src="//img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js" crossorigin></script></body></html>