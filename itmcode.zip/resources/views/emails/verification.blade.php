<!DOCTYPE html>
<html>
<head>
    <title>ITM Money</title>
</head>
<body>
    <h1>Hi {{ $details['name'] }} </h1>
    <p>Kindly Verify your email by  4 digits OTP </p>
    <hr/>
    <h3>OTP : {{ $details['otp'] }}</h3>
   
    <p>Thank you</p>
</body>
</html>